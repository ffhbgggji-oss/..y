extends Node
class_name RigBoneController

## Editing and interpolation utilities for an imported Skeleton3D.
var skeleton: Skeleton3D

func bind_skeleton(value: Skeleton3D) -> void:
    skeleton = value

func pick_bone(camera: Camera3D, screen_position: Vector2, radius: float = 68.0) -> int:
    if not is_instance_valid(skeleton) or not is_instance_valid(camera):
        return -1
    var best_index := -1
    var best_distance := radius
    for index in range(skeleton.get_bone_count()):
        var world_position: Vector3 = skeleton.global_transform * skeleton.get_bone_global_pose(index).origin
        if camera.is_position_behind(world_position):
            continue
        var distance := camera.unproject_position(world_position).distance_to(screen_position)
        if distance < best_distance:
            best_distance = distance
            best_index = index
    return best_index

func capture_pose() -> Dictionary:
    var result: Dictionary = {}
    if not is_instance_valid(skeleton):
        return result
    for index in range(skeleton.get_bone_count()):
        result[str(index)] = {
            "position": skeleton.get_bone_pose_position(index),
            "rotation": skeleton.get_bone_pose_rotation(index),
            "scale": skeleton.get_bone_pose_scale(index)
        }
    return result

func apply_pose(pose: Dictionary) -> void:
    if not is_instance_valid(skeleton):
        return
    for key in pose.keys():
        var index := int(key)
        if index < 0 or index >= skeleton.get_bone_count():
            continue
        var item: Dictionary = pose[key]
        skeleton.set_bone_pose_position(index, item.get("position", skeleton.get_bone_pose_position(index)))
        skeleton.set_bone_pose_rotation(index, item.get("rotation", skeleton.get_bone_pose_rotation(index)))
        skeleton.set_bone_pose_scale(index, item.get("scale", skeleton.get_bone_pose_scale(index)))

func interpolate_pose(from_pose: Dictionary, to_pose: Dictionary, weight: float) -> Dictionary:
    var result: Dictionary = {}
    var t := clampf(weight, 0.0, 1.0)
    for key in from_pose.keys():
        if not to_pose.has(key):
            continue
        var a: Dictionary = from_pose[key]
        var b: Dictionary = to_pose[key]
        var qa: Quaternion = a.get("rotation", Quaternion.IDENTITY)
        var qb: Quaternion = b.get("rotation", Quaternion.IDENTITY)
        result[key] = {
            "position": (a.get("position", Vector3.ZERO) as Vector3).lerp(b.get("position", Vector3.ZERO), t),
            "rotation": qa.slerp(qb, t).normalized(),
            "scale": (a.get("scale", Vector3.ONE) as Vector3).lerp(b.get("scale", Vector3.ONE), t)
        }
    return result

func rotate_bone_from_drag(index: int, relative: Vector2, camera: Camera3D, sensitivity: float = 0.010) -> bool:
    if not _valid_bone(index):
        return false
    var right := camera.global_basis.x.normalized() if is_instance_valid(camera) else Vector3.RIGHT
    var up := camera.global_basis.y.normalized() if is_instance_valid(camera) else Vector3.UP
    var world_delta := Quaternion(up, -relative.x * sensitivity) * Quaternion(right, -relative.y * sensitivity)
    var parent_basis := _parent_global_basis(index)
    var local_delta := Quaternion(parent_basis.inverse() * Basis(world_delta) * parent_basis)
    skeleton.set_bone_pose_rotation(index, (local_delta * skeleton.get_bone_pose_rotation(index)).normalized())
    return true

func move_bone_from_drag(index: int, relative: Vector2, camera: Camera3D, units_per_pixel: float = 0.004) -> bool:
    if not _valid_bone(index):
        return false
    var right := camera.global_basis.x.normalized() if is_instance_valid(camera) else Vector3.RIGHT
    var up := camera.global_basis.y.normalized() if is_instance_valid(camera) else Vector3.UP
    var world_delta := right * relative.x * units_per_pixel - up * relative.y * units_per_pixel
    skeleton.set_bone_pose_position(index, skeleton.get_bone_pose_position(index) + _parent_global_basis(index).inverse() * world_delta)
    return true

func scale_bone_from_drag(index: int, relative: Vector2, sensitivity: float = 0.006) -> bool:
    if not _valid_bone(index):
        return false
    var factor := exp(-relative.y * sensitivity)
    var value := skeleton.get_bone_pose_scale(index) * factor
    value.x = clampf(value.x, 0.1, 4.0)
    value.y = clampf(value.y, 0.1, 4.0)
    value.z = clampf(value.z, 0.1, 4.0)
    skeleton.set_bone_pose_scale(index, value)
    return true

func bone_name(index: int) -> String:
    return skeleton.get_bone_name(index) if _valid_bone(index) else ""

func _valid_bone(index: int) -> bool:
    return is_instance_valid(skeleton) and index >= 0 and index < skeleton.get_bone_count()

func _parent_global_basis(index: int) -> Basis:
    var parent_index := skeleton.get_bone_parent(index)
    if parent_index < 0:
        return skeleton.global_basis.orthonormalized()
    return (skeleton.global_transform * skeleton.get_bone_global_pose(parent_index)).basis.orthonormalized()


func move_bone_axis_from_drag(index: int, relative: Vector2, camera: Camera3D, axis_mode: String, units_per_pixel: float = 0.006) -> bool:
    if not _valid_bone(index) or not is_instance_valid(camera):
        return false
    var axis := _axis_vector(axis_mode)
    if axis_mode == "screen":
        return move_bone_from_drag(index, relative, camera, units_per_pixel)
    var bone_world := skeleton.global_transform * skeleton.get_bone_global_pose(index).origin
    var screen_start := camera.unproject_position(bone_world)
    var screen_end := camera.unproject_position(bone_world + axis)
    var projected := screen_end - screen_start
    if projected.length() < 0.001:
        return false
    var pixels := relative.dot(projected.normalized())
    var world_delta := axis * pixels * units_per_pixel
    var local_delta := _parent_global_basis(index).inverse() * world_delta
    skeleton.set_bone_pose_position(index, skeleton.get_bone_pose_position(index) + local_delta)
    return true

func rotate_bone_axis_from_drag(index: int, relative: Vector2, camera: Camera3D, axis_mode: String, sensitivity: float = 0.010) -> bool:
    if not _valid_bone(index):
        return false
    if axis_mode == "screen":
        return rotate_bone_from_drag(index, relative, camera, sensitivity)
    var axis := _axis_vector(axis_mode)
    var angle := (relative.x - relative.y) * sensitivity
    var world_delta := Quaternion(axis, -angle)
    var parent_basis := _parent_global_basis(index)
    var local_delta := Quaternion(parent_basis.inverse() * Basis(world_delta) * parent_basis)
    skeleton.set_bone_pose_rotation(index, (local_delta * skeleton.get_bone_pose_rotation(index)).normalized())
    return true

func scale_bone_axis_from_drag(index: int, relative: Vector2, axis_mode: String, sensitivity: float = 0.006) -> bool:
    if not _valid_bone(index):
        return false
    var factor := exp(-relative.y * sensitivity)
    var value := skeleton.get_bone_pose_scale(index)
    if axis_mode == "X":
        value.x = clampf(value.x * factor, 0.1, 4.0)
    elif axis_mode == "Y":
        value.y = clampf(value.y * factor, 0.1, 4.0)
    elif axis_mode == "Z":
        value.z = clampf(value.z * factor, 0.1, 4.0)
    else:
        value *= factor
        value.x = clampf(value.x, 0.1, 4.0)
        value.y = clampf(value.y, 0.1, 4.0)
        value.z = clampf(value.z, 0.1, 4.0)
    skeleton.set_bone_pose_scale(index, value)
    return true

func _axis_vector(axis_mode: String) -> Vector3:
    match axis_mode:
        "X": return Vector3.RIGHT
        "Y": return Vector3.UP
        "Z": return Vector3.BACK
        _: return Vector3.ZERO


## CCD inverse-kinematics solver. The selected bone is the end effector;
## its ancestors are rotated toward target_world in skeleton-local space.
func solve_ik_ccd(end_bone: int, target_world: Vector3, iterations: int = 16, tolerance: float = 0.015, max_chain_depth: int = 12) -> bool:
    if not _valid_bone(end_bone):
        return false
    var target_local: Vector3 = skeleton.global_transform.affine_inverse() * target_world
    var changed := false
    var chain: Array[int] = []
    var joint := skeleton.get_bone_parent(end_bone)
    while joint >= 0 and chain.size() < max_chain_depth:
        chain.append(joint)
        joint = skeleton.get_bone_parent(joint)
    if chain.is_empty():
        return false

    for _iteration in range(clampi(iterations, 1, 64)):
        skeleton.force_update_all_bone_transforms()
        var effector: Vector3 = skeleton.get_bone_global_pose(end_bone).origin
        if effector.distance_to(target_local) <= tolerance:
            break
        for joint_index in chain:
            skeleton.force_update_all_bone_transforms()
            effector = skeleton.get_bone_global_pose(end_bone).origin
            var pivot: Vector3 = skeleton.get_bone_global_pose(joint_index).origin
            var to_effector := effector - pivot
            var to_target := target_local - pivot
            if to_effector.length_squared() < 0.000001 or to_target.length_squared() < 0.000001:
                continue
            var from_dir := to_effector.normalized()
            var to_dir := to_target.normalized()
            if from_dir.dot(to_dir) > 0.99999:
                continue
            var world_delta := Quaternion(from_dir, to_dir).normalized()
            var parent_basis := _parent_skeleton_basis(joint_index)
            var local_delta := Quaternion(parent_basis.inverse() * Basis(world_delta) * parent_basis).normalized()
            var current_rotation := skeleton.get_bone_pose_rotation(joint_index)
            skeleton.set_bone_pose_rotation(joint_index, (local_delta * current_rotation).normalized())
            changed = true
        skeleton.force_update_all_bone_transforms()
        if skeleton.get_bone_global_pose(end_bone).origin.distance_to(target_local) <= tolerance:
            break
    return changed

func _parent_skeleton_basis(index: int) -> Basis:
    var parent_index := skeleton.get_bone_parent(index)
    if parent_index < 0:
        return Basis.IDENTITY
    return skeleton.get_bone_global_pose(parent_index).basis.orthonormalized()
