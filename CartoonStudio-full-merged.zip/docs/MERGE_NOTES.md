# Merge notes

This archive is based on CartoonStudio-bone-gizmo-selection.zip.
Added from CartoonStudio-animation-preserved-fixed.zip:
- scripts/ObjRuntimeImporter.gd
- scripts/AudioTimeline.gd
- docs/AUDIO_AND_OBJ.md

No existing files from the visual/gizmo archive were overwritten.
The two added scripts are included as source files; runtime integration and Android testing have not been verified.
